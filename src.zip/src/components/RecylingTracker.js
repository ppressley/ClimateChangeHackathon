import React, { useState, useEffect } from 'react';
import './recyclingtracker.css';

const RecyclingTracker = () => {
  const [recycledItems, setRecycledItems] = useState(0);

  useEffect(() => {
    if (recycledItems % 10 === 0 && recycledItems !== 0) {
      alert('Congratulations on completing 10 recycles!');
    }
  }, [recycledItems]);

  const handleRecycle = () => {
    setRecycledItems(recycledItems + 1);
  };

  return (
    <div className="recycling-tracker">
      <h1>Recycling Tracker</h1>
      <p className="total-items">Total Items Recycled: {recycledItems}</p>
      <button className="recycle-button" onClick={handleRecycle}>
        Recycle
      </button>
    </div>
  );
};

export default RecyclingTracker;