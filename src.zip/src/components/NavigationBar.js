import { FaHome, FaPlus, FaRecycle } from 'react-icons/fa';
import Window from './Window';
import React, { useState } from 'react';

const NavigationBar = () => {
  const handleHomeClick = () => {
    console.log('Home icon clicked');
    // Add your home icon functionality here
  }

  const handleSearchClick = () => {
    console.log('Search icon clicked');
    // Add your search icon functionality here
  }

  const handlePlusClick = () => {
    console.log('Plus icon clicked');
    handleOpen();
  }


  // WINDOW FUNC
  const [windowVisible, setWindowVisible] = useState(false);

  const handleClose = () => {
    setWindowVisible(false);
  };

  const handleOpen = () => {
    setWindowVisible(true);
  };

  
  return (
    <div>
        <div className="nav-bar">
        <FaHome onClick={handleHomeClick} />
        <FaRecycle onClick={handleSearchClick} />
        <FaPlus onClick={handlePlusClick} />
        </div>
        {windowVisible && (
        <Window title="My Window" onClose={handleClose} top="350px">
          <p>This is the content of my window.</p>
        </Window>
      )}
    </div>
  );
}

export default NavigationBar;