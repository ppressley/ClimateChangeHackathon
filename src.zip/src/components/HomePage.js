import React from 'react';

const HomePage = () => {
  return (
    <body>
        <div className='homediv'>
            <h2>Recycle Tracker</h2>
            <p>In the recycle tracker app we check how much you recycle so that you can maintain a healthy planet.</p>
            <form>
                <input type="text" id="inputa" name="inputa" placeholder='How often Recycled' className='inputhome'/>
                <br></br>
                <br></br>
                <input type="text" id="inputb" name="inputb" placeholder='Weight of Recycled' className='inputhome'/>
                <br></br>
                <br></br>
                <input type="text" id="inputc" name="inputc" placeholder='Some other third thing' className='inputhome'/>
                <br></br>
                <br></br>
                <input type="text" id="inputd" name="inputd" placeholder='Some other fourth thing' className='inputhome'/>
                
            </form>
        </div>
    </body>
  );
}

export default HomePage;