import React from 'react';

function Window(props) {
  const { title, onClose, children, top } = props;

  const handleClose = () => {
    onClose();
  };

  return (
    <div className="window" style={{ top: top }}>
      <div className="window-header">
        <div className="window-title">{title}</div>
        <div className="window-controls">
          <button onClick={handleClose}>X</button>
        </div>
      </div>
      <div className="window-content">{children}</div>
    </div>
  );
}

export default Window;
