import React, { useState } from 'react';

const LoginPage = () => {
  const [username, setUsername] = useState('');

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Do something with the username, such as saving it to a state or sending it to an API
    console.log('Submitted username:', username);
  };

  return (
    <div>
      <h1>Login Page</h1>
      <form onSubmit={handleSubmit}>
          <input type="text" value={username} onChange={handleUsernameChange} placeholder='Username'/>
          <br></br>
          <br></br>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default LoginPage;
