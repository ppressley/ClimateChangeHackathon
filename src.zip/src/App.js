import './App.css';
import React, { useState } from 'react';
import NavigationBar from './components/NavigationBar';
import RecyclingTracker from './components/RecylingTracker';
import HomePage from './components/HomePage';
import LoginPage from './components/LoginPage';

let component;
  switch (window.location.pathname) {
    case "/home":
      component = <HomePage />;
      break;
    case "/recyclingtracker":
      component = <RecyclingTracker />
      break;
    default:
      component = <LoginPage />;
      break;
  }

function App() {

  const [showProfile, setShowProfile] = useState(false);

  const toggleProfile = () => {
    setShowProfile(!showProfile);
  };

  return (
    <div className="App">
      <div className="top-bar">
        <div className="profile-icon" onClick={toggleProfile}>
          {/* Icon component or image */}
        </div>
      </div>

      {showProfile && (
        <div className="profile">
          {/* Profile content */}
        </div>
      )}
      <h1 className="app-heading">One Man's Trash is Another's Treasure</h1>
      {component}
      <NavigationBar/>
    </div>
  );
}

export default App;